"""TALOS Social self-hosted multi-tenant application. Python 3.11+, FastAPI."""
import os, sqlite3, secrets, hashlib, hmac, json, urllib.request
from datetime import datetime, timezone, timedelta
from contextlib import contextmanager
from pathlib import Path
from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

ROOT=Path(__file__).resolve().parent
DB=os.getenv('TALOS_DB',str(ROOT/'talos.sqlite3'))
Path(DB).parent.mkdir(parents=True,exist_ok=True)
app=FastAPI(title='TALOS Social API',version='1.0.0')

def now(): return datetime.now(timezone.utc).isoformat()
@contextmanager
def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    try: yield c; c.commit()
    finally: c.close()
def password_hash(p,s=None):
    s=s or secrets.token_hex(16)
    return s+':'+hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(s),260000).hex()
def password_ok(p,v):
    try: s,_=v.split(':'); return hmac.compare_digest(password_hash(p,s),v)
    except Exception:return False

def setup():
    with conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS orgs(id TEXT PRIMARY KEY,name TEXT NOT NULL,color TEXT NOT NULL DEFAULT '#6de2c1',voice TEXT NOT NULL DEFAULT 'Professional and human',timezone TEXT NOT NULL DEFAULT 'America/New_York',cadence TEXT NOT NULL DEFAULT 'Tuesday: Jobs; Thursday: Employer brand');
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,org_id TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','reviewer','recruiter')),FOREIGN KEY(org_id) REFERENCES orgs(id));
        CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS posts(id TEXT PRIMARY KEY,org_id TEXT NOT NULL,author_id TEXT NOT NULL,topic TEXT NOT NULL,post_text TEXT NOT NULL,day_route TEXT NOT NULL DEFAULT '',assignment_number INTEGER NOT NULL DEFAULT 0,hook_style TEXT NOT NULL DEFAULT '',framework TEXT NOT NULL DEFAULT '',authority_signal TEXT NOT NULL DEFAULT '',similarity_score REAL,status TEXT NOT NULL DEFAULT 'draft',scheduled_at TEXT,published_at TEXT,linkedin_post_urn TEXT,feedback TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY,org_id TEXT NOT NULL,user_id TEXT NOT NULL,action TEXT NOT NULL,post_id TEXT,details TEXT NOT NULL,at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS integrations(org_id TEXT PRIMARY KEY,mode TEXT NOT NULL DEFAULT 'disabled',webhook_url TEXT NOT NULL DEFAULT '',secret_hash TEXT NOT NULL DEFAULT '');
        CREATE TABLE IF NOT EXISTS dispatches(id TEXT PRIMARY KEY,org_id TEXT NOT NULL,post_id TEXT NOT NULL UNIQUE,state TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,external_id TEXT NOT NULL DEFAULT '',error TEXT NOT NULL DEFAULT '');
        CREATE INDEX IF NOT EXISTS posts_org ON posts(org_id);
        CREATE INDEX IF NOT EXISTS audit_org ON audit(org_id);
        ''')
        cols=[x[1] for x in c.execute('PRAGMA table_info(users)')]
        if 'active' not in cols:c.execute('ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1')
        orgcols=[x[1] for x in c.execute('PRAGMA table_info(orgs)')]
        if 'onboarding_done' not in orgcols:c.execute('ALTER TABLE orgs ADD COLUMN onboarding_done INTEGER NOT NULL DEFAULT 0')
        if os.getenv('TALOS_BOOTSTRAP_EMAIL') and os.getenv('TALOS_BOOTSTRAP_PASSWORD'):
            email=os.environ['TALOS_BOOTSTRAP_EMAIL'].strip().lower()
            if not c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone():
                oid=secrets.token_hex(12); uid=secrets.token_hex(12)
                c.execute('INSERT INTO orgs(id,name) VALUES(?,?)',(oid,os.getenv('TALOS_BOOTSTRAP_ORG','My Recruiting Team')))
                c.execute('INSERT INTO users(id,org_id,email,password,role) VALUES(?,?,?,?,?)',(uid,oid,email,password_hash(os.environ['TALOS_BOOTSTRAP_PASSWORD']),'admin'))
setup()

class InitialSetup(BaseModel):
    email:str; password:str=Field(min_length=12); organization:str=Field(min_length=1,max_length=120)
class AccountUpdate(BaseModel):
    role:str|None=None; active:bool|None=None; password:str|None=Field(default=None,min_length=12)
class PasswordChange(BaseModel):
    current_password:str; new_password:str=Field(min_length=12)
class Login(BaseModel): email:str; password:str
class PostIn(BaseModel): topic:str=Field(min_length=1,max_length=180); post_text:str=Field(min_length=1,max_length=10000); day_route:str=''; assignment_number:int=0; hook_style:str=''; framework:str=''; authority_signal:str=''; scheduled_at:str|None=None
class Decision(BaseModel): feedback:str=''
class OrgIn(BaseModel): name:str=Field(min_length=1,max_length=120); color:str=Field(pattern=r'^#[0-9a-fA-F]{6}$'); voice:str=Field(max_length=1000); timezone:str=Field(max_length=80); cadence:str=Field(max_length=500)
class OnboardingIn(BaseModel):
    name:str=Field(min_length=1,max_length=120)
    color:str=Field(pattern=r'^#[0-9a-fA-F]{6}$')
    voice:str=Field(max_length=1000)
    timezone:str=Field(max_length=80)
    cadence:str=Field(max_length=500)
    team_mode:str=Field(pattern='^(solo|team)$')
    admin_email:str|None=None
    admin_password:str|None=None
    teammate_email:str|None=None
    teammate_password:str|None=None

class UserIn(BaseModel): email:str; password:str=Field(min_length=12); role:str
class IntegrationIn(BaseModel): mode:str=Field(pattern='^(disabled|mock|make)$'); webhook_url:str=''; callback_secret:str=''
class CallbackIn(BaseModel): dispatch_id:str; status:str=Field(pattern='^(published|failed)$'); linkedin_post_urn:str=''; error:str=''

def auth(authorization:str=Header(default='')):
    token=authorization.removeprefix('Bearer ').strip()
    if not token: raise HTTPException(401,'Sign in required')
    with conn() as c:
        u=c.execute('SELECT users.* FROM sessions JOIN users ON sessions.user_id=users.id WHERE token_hash=? AND expires>?',(hashlib.sha256(token.encode()).hexdigest(),now())).fetchone()
        if not u or not u['active']: raise HTTPException(401,'Session expired or account disabled')
        return dict(u)
def permitted(u,roles):
    if u['role'] not in roles: raise HTTPException(403,'Insufficient permissions')
def audit(c,u,action,pid=None,details=''):
    c.execute('INSERT INTO audit VALUES(?,?,?,?,?,?,?)',(secrets.token_hex(12),u['org_id'],u['id'],action,pid,details,now()))
def get_post(c,u,pid):
    p=c.execute('SELECT * FROM posts WHERE id=? AND org_id=?',(pid,u['org_id'])).fetchone()
    if not p: raise HTTPException(404,'Post not found')
    return dict(p)
@app.get('/')
def home(): return FileResponse(ROOT/'app.html')

@app.get('/preview')
def preview(): return FileResponse(ROOT/'frontend-preview.html')
@app.get('/api/setup/status')
def setup_status():
    with conn() as c:return {'setup_required':c.execute('SELECT COUNT(*) FROM users').fetchone()[0]==0}
@app.post('/api/setup')
def initial_setup(v:InitialSetup,request:Request):
    # First owner registration is local-only; never expose this over a public host.
    if request.client.host not in ('127.0.0.1','::1','testclient'):
        raise HTTPException(403,'Initial setup is allowed only from localhost')
    with conn() as c:
        if c.execute('SELECT COUNT(*) FROM users').fetchone()[0]:raise HTTPException(409,'Already configured')
        oid=secrets.token_hex(12);uid=secrets.token_hex(12)
        c.execute('INSERT INTO orgs(id,name) VALUES(?,?)',(oid,v.organization))
        c.execute('INSERT INTO users(id,org_id,email,password,role) VALUES(?,?,?,?,?)',(uid,oid,v.email.strip().lower(),password_hash(v.password),'admin'))
    return {'ok':True}
@app.post('/api/login')
def login(v:Login):
    with conn() as c:
        u=c.execute('SELECT * FROM users WHERE email=?',(v.email.strip().lower(),)).fetchone()
        if not u or not u['active'] or not password_ok(v.password,u['password']):raise HTTPException(401,'Invalid credentials')
        token=secrets.token_urlsafe(32)
        c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),u['id'],(datetime.now(timezone.utc)+timedelta(hours=12)).isoformat()))
        return {'token':token,'role':u['role']}
@app.post('/api/logout')
def logout(authorization:str=Header(default=''),u=Depends(auth)):
    with conn() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(authorization.removeprefix('Bearer ').strip().encode()).hexdigest(),))
    return {'ok':True}
@app.get('/api/me')
def me(u=Depends(auth)):
    with conn() as c:
        o=dict(c.execute('SELECT * FROM orgs WHERE id=?',(u['org_id'],)).fetchone())
    return {'email':u['email'],'role':u['role'],'organization':o}
@app.post('/api/onboarding')
def complete_onboarding(v:OnboardingIn,u=Depends(auth)):
    permitted(u,['admin'])
    if v.admin_email and (not v.admin_password or len(v.admin_password)<12):raise HTTPException(400,'Administrator password must have 12+ characters')
    if v.teammate_email and (not v.teammate_password or len(v.teammate_password)<12):raise HTTPException(400,'Recruiter password must have 12+ characters')
    with conn() as c:
        try:
            c.execute('UPDATE orgs SET name=?,color=?,voice=?,timezone=?,cadence=?,onboarding_done=1 WHERE id=?',(v.name,v.color,v.voice,v.timezone,v.cadence,u['org_id']))
            for email,password,role in [(v.admin_email,v.admin_password,'admin'),(v.teammate_email,v.teammate_password,'recruiter')]:
                if email and email.strip().lower()!=u['email']:
                    c.execute('INSERT INTO users(id,org_id,email,password,role) VALUES(?,?,?,?,?)',(secrets.token_hex(12),u['org_id'],email.strip().lower(),password_hash(password),role))
            audit(c,u,'onboarding.completed',details=v.team_mode)
        except sqlite3.IntegrityError:raise HTTPException(409,'A team email already exists')
    return {'ok':True}

@app.post('/api/users')
def add_user(v:UserIn,u=Depends(auth)):
    permitted(u,['admin'])
    if v.role not in ('admin','reviewer','recruiter'):raise HTTPException(400,'Invalid role')
    with conn() as c:
        try:c.execute('INSERT INTO users(id,org_id,email,password,role) VALUES(?,?,?,?,?)',(secrets.token_hex(12),u['org_id'],v.email.lower(),password_hash(v.password),v.role))
        except sqlite3.IntegrityError:raise HTTPException(409,'Email already exists')
        audit(c,u,'user.created',details=v.email)
    return {'ok':True}
@app.get('/api/users')
def list_users(u=Depends(auth)):
    permitted(u,['admin'])
    with conn() as c:return [dict(x) for x in c.execute('SELECT id,email,role,active FROM users WHERE org_id=? ORDER BY email',(u['org_id'],))]
@app.patch('/api/users/{uid}')
def edit_user(uid:str,v:AccountUpdate,u=Depends(auth)):
    permitted(u,['admin'])
    with conn() as c:
        target=c.execute('SELECT * FROM users WHERE id=? AND org_id=?',(uid,u['org_id'])).fetchone()
        if not target:raise HTTPException(404,'User not found')
        if v.role is not None and v.role not in ('admin','reviewer','recruiter'):raise HTTPException(400,'Invalid role')
        role=v.role if v.role is not None else target['role']
        active=int(v.active) if v.active is not None else target['active']
        if target['id']==u['id'] and (role!='admin' or not active):raise HTTPException(400,'Cannot remove your own administrator access')
        if target['role']=='admin' and (role!='admin' or not active):
            count=c.execute("SELECT COUNT(*) FROM users WHERE org_id=? AND role='admin' AND active=1",(u['org_id'],)).fetchone()[0]
            if count<=1:raise HTTPException(400,'At least one active administrator is required')
        c.execute('UPDATE users SET role=?,active=? WHERE id=?',(role,active,uid))
        if v.password is not None:c.execute('UPDATE users SET password=? WHERE id=?',(password_hash(v.password),uid))
        if not active or v.password is not None:c.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
        audit(c,u,'user.updated',details=target['email'])
    return {'ok':True}
@app.post('/api/account/password')
def change_password(v:PasswordChange,u=Depends(auth)):
    if not password_ok(v.current_password,u['password']):raise HTTPException(403,'Current password incorrect')
    with conn() as c:
        c.execute('UPDATE users SET password=? WHERE id=?',(password_hash(v.new_password),u['id']))
        c.execute('DELETE FROM sessions WHERE user_id=?',(u['id'],))
        audit(c,u,'password.changed')
    return {'ok':True,'message':'Password updated. Sign in again.'}
@app.put('/api/organization')
def update_org(v:OrgIn,u=Depends(auth)):
    permitted(u,['admin'])
    with conn() as c:
        c.execute('UPDATE orgs SET name=?,color=?,voice=?,timezone=?,cadence=? WHERE id=?',(*v.model_dump().values(),u['org_id']))
        audit(c,u,'organization.updated')
    return {'ok':True}
@app.get('/api/posts')
def posts(u=Depends(auth)):
    with conn() as c:return [dict(x) for x in c.execute('SELECT * FROM posts WHERE org_id=? ORDER BY created_at DESC',(u['org_id'],))]
@app.post('/api/posts')
def create_post(v:PostIn,u=Depends(auth)):
    pid=secrets.token_hex(12); d=v.model_dump()
    with conn() as c:
        c.execute('''INSERT INTO posts(id,org_id,author_id,topic,post_text,day_route,assignment_number,hook_style,framework,authority_signal,scheduled_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',(pid,u['org_id'],u['id'],d['topic'],d['post_text'],d['day_route'],d['assignment_number'],d['hook_style'],d['framework'],d['authority_signal'],d['scheduled_at'],now(),now()))
        audit(c,u,'post.created',pid)
    return {'id':pid,'status':'draft'}
@app.post('/api/posts/{pid}/submit')
def submit(pid:str,u=Depends(auth)):
    with conn() as c:
        p=get_post(c,u,pid)
        if p['status'] not in ('draft','rejected'):raise HTTPException(409,'Cannot submit this status')
        if p['author_id']!=u['id'] and u['role']!='admin':raise HTTPException(403,'Not your draft')
        c.execute('UPDATE posts SET status=?,updated_at=? WHERE id=?',('pending',now(),pid));audit(c,u,'post.submitted',pid)
    return {'status':'pending'}
@app.post('/api/posts/{pid}/approve')
def approve(pid:str,u=Depends(auth)):
    permitted(u,['reviewer','admin'])
    with conn() as c:
        p=get_post(c,u,pid)
        if p['status']!='pending':raise HTTPException(409,'Only pending posts can be approved')
        if p['author_id']==u['id']:raise HTTPException(403,'Separate reviewer required')
        c.execute('UPDATE posts SET status=?,updated_at=? WHERE id=?',('approved',now(),pid));audit(c,u,'post.approved',pid)
    return {'status':'approved'}
@app.post('/api/posts/{pid}/reject')
def reject(pid:str,v:Decision,u=Depends(auth)):
    permitted(u,['reviewer','admin'])
    with conn() as c:
        p=get_post(c,u,pid)
        if p['status']!='pending':raise HTTPException(409,'Only pending posts can be rejected')
        c.execute('UPDATE posts SET status=?,feedback=?,updated_at=? WHERE id=?',('rejected',v.feedback,now(),pid));audit(c,u,'post.rejected',pid,v.feedback)
    return {'status':'rejected'}
@app.post('/api/posts/{pid}/publish')
def publish(pid:str,u=Depends(auth)):
    permitted(u,['admin'])
    with conn() as c:
        p=get_post(c,u,pid)
        if p['status']!='approved':raise HTTPException(409,'Approval required')
        # Queue only; publishing requires an explicitly configured authorized integration.
        c.execute('UPDATE posts SET status=?,updated_at=? WHERE id=?',('queued',now(),pid));audit(c,u,'post.queued',pid)
    return {'status':'queued','message':'Queued; not published to LinkedIn'}
@app.get('/api/audit')
def history(u=Depends(auth)):
    permitted(u,['admin'])
    with conn() as c:return [dict(x) for x in c.execute('SELECT * FROM audit WHERE org_id=? ORDER BY at DESC LIMIT 250',(u['org_id'],))]
@app.get('/api/health')
def health():return {'status':'ok'}


@app.put('/api/integration')
def configure_integration(v:IntegrationIn,u=Depends(auth)):
    permitted(u,['admin'])
    if v.mode=='make':
        from urllib.parse import urlparse
        parsed=urlparse(v.webhook_url)
        if parsed.scheme!='https' or not parsed.hostname or parsed.hostname not in ('hook.make.com','hook.eu1.make.com','hook.eu2.make.com','hook.us1.make.com','hook.us2.make.com'):
            raise HTTPException(400,'Only HTTPS Make webhook endpoints are supported')
        if len(v.callback_secret)<24:raise HTTPException(400,'Callback secret must be at least 24 characters')
    with conn() as c:
        c.execute('INSERT OR REPLACE INTO integrations(org_id,mode,webhook_url,secret_hash) VALUES(?,?,?,?)',(u['org_id'],v.mode,v.webhook_url if v.mode=='make' else '',hashlib.sha256(v.callback_secret.encode()).hexdigest() if v.mode=='make' else ''))
        audit(c,u,'integration.configured',details=v.mode)
    return {'mode':v.mode,'message':'Saved; existing queued posts require manual dispatch'}

@app.get('/api/integration')
def integration_status(u=Depends(auth)):
    with conn() as c:r=c.execute('SELECT mode FROM integrations WHERE org_id=?',(u['org_id'],)).fetchone()
    return {'mode':r['mode'] if r else 'disabled'}

@app.post('/api/posts/{pid}/dispatch')
def dispatch(pid:str,u=Depends(auth)):
    permitted(u,['admin'])
    with conn() as c:
        p=get_post(c,u,pid)
        if p['status']!='queued':raise HTTPException(409,'Post must be queued')
        existing=c.execute('SELECT * FROM dispatches WHERE post_id=?',(pid,)).fetchone()
        if existing:raise HTTPException(409,'Dispatch already exists; duplicate prevented')
        cfg=c.execute('SELECT * FROM integrations WHERE org_id=?',(u['org_id'],)).fetchone()
        mode=cfg['mode'] if cfg else 'disabled'
        if mode=='disabled':raise HTTPException(409,'Publishing integration is disabled')
        did=secrets.token_hex(16)
        c.execute('INSERT INTO dispatches(id,org_id,post_id,state,created_at,updated_at) VALUES(?,?,?,?,?,?)',(did,u['org_id'],pid,'processing',now(),now()))
        audit(c,u,'dispatch.created',pid,mode)
    if mode=='mock':
        with conn() as c:
            urn='mock:linkedin:'+did
            c.execute('UPDATE dispatches SET state=?,external_id=?,updated_at=? WHERE id=?',('published',urn,now(),did))
            c.execute('UPDATE posts SET status=?,linkedin_post_urn=?,published_at=?,updated_at=? WHERE id=?',('published',urn,now(),now(),pid))
            audit(c,u,'dispatch.mock_published',pid,urn)
        return {'status':'published','simulated':True,'dispatch_id':did,'linkedin_post_urn':urn}
    # Network delivery is explicitly opt-in; Make must be modified to accept this schema.
    payload={'dispatch_id':did,'post_id':pid,'org_id':u['org_id'],'action':'publish','post_text':p['post_text'],'topic':p['topic'],'day_route':p['day_route']}
    try:
        req=urllib.request.Request(cfg['webhook_url'],data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','User-Agent':'TALOS-Social/1.1'},method='POST')
        with urllib.request.urlopen(req,timeout=12) as response:
            if response.status>=300:raise ValueError('Webhook returned non-success')
    except Exception:
        with conn() as c:
            c.execute('UPDATE dispatches SET state=?,error=?,updated_at=? WHERE id=?',('uncertain','Delivery failed or timed out; inspect Make before retrying',now(),did))
            audit(c,u,'dispatch.uncertain',pid)
        raise HTTPException(502,'Delivery unconfirmed. Do not retry automatically; inspect Make history.')
    return {'status':'processing','dispatch_id':did,'message':'Sent to Make; awaiting authenticated confirmation'}

@app.post('/api/integrations/make/callback')
async def make_callback(request:Request,x_talos_secret:str=Header(default='')):
    # Separate org-specific callback credential. Never expose it to a browser.
    try:v=CallbackIn.model_validate(await request.json())
    except Exception:raise HTTPException(400,'Invalid callback')
    with conn() as c:
        d=c.execute('SELECT * FROM dispatches WHERE id=?',(v.dispatch_id,)).fetchone()
        if not d:raise HTTPException(404,'Dispatch not found')
        cfg=c.execute('SELECT * FROM integrations WHERE org_id=?',(d['org_id'],)).fetchone()
        if not cfg or cfg['mode']!='make' or not x_talos_secret or not hmac.compare_digest(hashlib.sha256(x_talos_secret.encode()).hexdigest(),cfg['secret_hash']):raise HTTPException(403,'Invalid callback credential')
        if d['state'] in ('published','failed'):return {'status':d['state'],'idempotent':True}
        if v.status=='published' and not v.linkedin_post_urn:raise HTTPException(400,'Published callback requires LinkedIn URN')
        c.execute('UPDATE dispatches SET state=?,external_id=?,error=?,updated_at=? WHERE id=?',(v.status,v.linkedin_post_urn,v.error,now(),d['id']))
        if v.status=='published':c.execute('UPDATE posts SET status=?,linkedin_post_urn=?,published_at=?,updated_at=? WHERE id=?',('published',v.linkedin_post_urn,now(),now(),d['post_id']))
        else:c.execute('UPDATE posts SET status=?,updated_at=? WHERE id=?',('failed',now(),d['post_id']))
    return {'status':v.status}

@app.get('/api/dispatches')
def list_dispatches(u=Depends(auth)):
    permitted(u,['admin'])
    with conn() as c:return [dict(x) for x in c.execute('SELECT * FROM dispatches WHERE org_id=? ORDER BY created_at DESC',(u['org_id'],))]

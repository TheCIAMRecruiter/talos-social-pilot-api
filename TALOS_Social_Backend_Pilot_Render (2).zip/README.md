# TALOS Social — private backend pilot (Render)

This is the *working backend pilot*, separate from your existing static Render site. It provides login, workspace organization, draft/approval flow, audit history, mock dispatch and an opt-in Make webhook integration. It **does not** provide a working LinkedIn OAuth connection, autonomous content generation, scheduled job worker, or live publishing until external integrations are configured.

## Deploy without overwriting your current live website

1. Create a **new private GitHub repository** named `talos-social-pilot-api` and upload the files in this folder (not the parent ZIP). **Do not replace** the existing `talos-social` static website.
2. In Render choose **New → Blueprint** and select the new repository. Render reads `render.yaml`.
3. Configure `TALOS_BOOTSTRAP_EMAIL` and `TALOS_BOOTSTRAP_PASSWORD` as **secret environment variables**. Password must be strong and unique (12+ characters). Do not paste secrets into GitHub or chat.
4. Blueprint requests a **paid Starter web service and persistent disk**. Persistent disk is important: SQLite stored on an ephemeral filesystem will lose data on restarts. Review Render pricing before approval. You can instead use managed Postgres after migrating the SQLite storage layer.
5. After deployment open the new backend URL `/api/health` (should say `{"status":"ok"}`), then open `/` to sign in with the bootstrap account. `/preview` shows the latest static UI separately.
6. Keep integration mode **disabled** until the private pilot is tested. In the Integration tab, use mock mode to test without posting. Live Make requires a dedicated TALOS Make webhook, an org-specific callback secret, and valid LinkedIn API publishing permissions.

## Product architecture

Browser → TALOS API (login, roles, approvals, audit, org isolation) → Make webhook (private server-side orchestration) → approved LinkedIn integration → authenticated callback to TALOS.

Customers do **not** need Make accounts. Only TALOS administrators configure the integration. Never place Make webhook URLs, LinkedIn tokens, or callback secrets in browser JavaScript or downloadable configuration files.

## Known limitations / production checklist

- This is an **engineering pilot**, not a production-ready multi-customer SaaS. The server has an owner-bootstrap path controlled by environment variables; use private access and do not advertise it as public registration.
- SQLite with one persistent disk supports a limited single-instance pilot; use managed Postgres for scalable multi-tenant hosting and reliable backups.
- Do not enable live Make dispatch until OAuth, authorization, webhook signing/replay protections, rate limiting, secrets management, monitoring, backups, and retry/idempotency behavior have been reviewed.
- Make's workflows are not provisioned automatically. The provided existing blueprints are references, not production-installed integrations.
- The new frontend preview and the authenticated pilot UI are **different**: integrating the latest onboarding into the backend is the next UI development step.
- The existing static Render site remains unchanged until you choose to point it at the API or replace it with the authenticated app.

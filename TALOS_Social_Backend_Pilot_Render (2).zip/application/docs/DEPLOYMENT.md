# Deployment and operations

## Local setup

Install Python 3.11+ and `pip install -r requirements.txt`. Set `TALOS_BOOTSTRAP_EMAIL`, `TALOS_BOOTSTRAP_PASSWORD` (unique, long), and optionally `TALOS_BOOTSTRAP_ORG`. Run `uvicorn server:app --host 127.0.0.1 --port 8000` from the project directory, then visit http://127.0.0.1:8000. Never commit `.env` or `talos.sqlite3`.

## Deployment prerequisites

Put the service behind HTTPS, add rate limiting, CSRF/CORS and secure origin restrictions, backup/restore drills, account recovery, MFA/SSO, managed secrets, session revocation, invite links, abuse monitoring, privacy/retention controls, and Postgres migration before exposing it publicly. SQLite is for a small self-hosted pilot, not a multi-instance commercial launch. Verify and test tenant isolation and authorization independently. Restrict /docs or disable it in production. Review applicable data protection and LinkedIn API requirements.

## Multi-tenant operation

Each user belongs to an organization. Server derives org ID from the session; callers cannot supply an arbitrary tenant ID. Only admins manage branding and user creation; reviewers/admins review pending posts; post authors cannot approve their own submissions. Cross-organization posts return 404. Audit records are scoped to admin and organization. No cross-tenant UI switch is provided.

## Important publishing limitation

`POST /api/posts/{id}/publish` moves an approved post into `queued` only. It does NOT send a LinkedIn post or call Make. An authorized backend worker and platform permissions are required. Do not represent `queued` as `published`.

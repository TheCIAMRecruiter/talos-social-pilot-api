# Make integration blueprint

Existing fields: `post_id`, `published_at`, `day_route`, `assignment_number`, `topic`, `hook_style`, `framework`, `authority_signal`, `post_text`, `linkedin_post_urn`, `similarity_score`, `status`.

## Approved integration design (not yet connected)

1. A backend worker selects `queued` posts after schedule eligibility and enforces a unique idempotency key (`org_id:post_id:version`).
2. Worker authenticates to a per-organization Make scenario using a secret held in a server-side vault, never in HTML or logs.
3. Make Approval Handler / Authority Engine receive an org-scoped payload with the fields above, content rules, and a correlation ID. Existing approval logic must not silently bypass human approval in TALOS.
4. Make sends signed callbacks to the backend for `published` (with `linkedin_post_urn` and `published_at`) or `failed` (with safe diagnostic). Verify signatures, org mapping, timestamps and replay protection.
5. Retries use exponential backoff and deduplication; never repost after an ambiguous network timeout without checking prior success.
6. LinkedIn publication requires legitimate API authorization and permissions for the specific account/page. Do not automate personal accounts by scraping or browser impersonation.

The supplied backend does not implement the worker, Make callback, AI generation, or LinkedIn OAuth. These require actual Make scenario details and authorized accounts. Manual posting is the safe interim option.

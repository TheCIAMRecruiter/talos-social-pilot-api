# White-label partner guide

**Product:** TALOS Social. **Positioning:** Recruiting intelligence. Automated content. Human control.

## Partner onboarding

1. Provision a separate organization and administrator account (currently bootstrap creates one organization; additional org provisioning requires an internal operator script or admin service).
2. Admin sets company name, brand color, editorial voice, timezone, and cadence in White Label.
3. Create recruiter and reviewer accounts. Do not share logins.
4. Recruiter creates and submits draft; different reviewer approves; admin queues for authorized delivery.
5. Audit approval history and validate all publishing integrations in sandbox before production.

## Customer-facing instructions

Recruiters: draft a post with a clear topic, opening hook, evidence/authority signal, and call to action. Avoid personal candidate information. Submit for approval.

Reviewers: check facts, inclusion, employer brand, job availability, tone, and confidentiality. Approve only content ready to publish; otherwise reject with guidance.

Admins: configure branding, maintain roles, inspect audit events, and manage publishing authorization outside the browser.

## Commercial features not yet shipped

Custom domains, logo uploads, branded email notifications, billing, plan limits, reseller portals, delegated tenant provisioning, SSO, AI writing integrations, and usage analytics. Treat these as planned capabilities, not live features. Conduct a trademark/domain clearance before marketing the name.

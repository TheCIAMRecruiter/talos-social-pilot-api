# TALOS Social — Make publishing integration runbook

## Verified source behavior
The uploaded Authority Engine uses a five-day router, a Make data store for post history, AI generation, and approval email. The uploaded Approval Handler receives a webhook with `action` and `post_id`, searches for `PENDING_APPROVAL`, and uses the Nick Cox LinkedIn connection to publish on approval. Rejecting triggers AI regeneration and another approval email.

## Safety and white-label constraints
Do not reuse the exported personal webhook, connection IDs, email address, or employer-specific prompt in customer workspaces. The new TALOS `make` adapter is **not compatible out of the box** with the existing Approval Handler. It requires a separate scenario per authorized publishing identity (or an explicitly routed secure service), an isolated customer data store, and a new callback step.

## New scenario specification
1. In Make, create a NEW custom webhook. Do not modify the original scenarios during initial testing.
2. Configure the LinkedIn Create Post module with the test account's own authorized connection and the webhook `post_text`. Require the account owner to consent.
3. Validate `action=publish`, `dispatch_id`, `post_id`, `org_id`; ensure only the expected organization/account may publish. The Make webhook URL is a bearer secret: store only on server.
4. After successful LinkedIn posting, POST to `https://YOUR-TALOS-HOST/api/integrations/make/callback` with header `X-Talos-Secret: YOUR_PRIVATE_CALLBACK_SECRET` and JSON `{"dispatch_id":"<from webhook>","status":"published","linkedin_post_urn":"<LinkedIn module id>"}`.
5. If LinkedIn returns a definitive failure, callback with `{"dispatch_id":"...","status":"failed","error":"..."}`. Do not call `published` before the LinkedIn module succeeds.
6. In TALOS Integration, choose Make, enter your *new* Make webhook and a random 24+ character callback secret. Keep secret only in Make and TALOS server settings.
7. Create a draft, submit, have a DIFFERENT user approve, queue, dispatch, and verify LinkedIn URN and audit records.

## First, run mock test
Choose `mock` in Integration and follow the same workflow. A simulated `mock:linkedin:` ID is recorded. **This does not publish to LinkedIn.**

## Production blockers
- The current synchronous HTTP dispatch can enter an `uncertain` state on timeout. Inspect Make and LinkedIn before retrying; never blindly resubmit.
- Add a durable worker/outbox, webhook signing or stronger mutual authentication, key rotation, per-tenant OAuth credential lifecycle, rate limits, CSRF/session security, monitoring, backups, and operational recovery before commercial deployment.
- Existing AI generation and rejection regeneration are not yet connected to this application. They remain in the uploaded Make blueprints and need customer-specific prompt templating and isolated histories.
- Approval remains a manual separate-reviewer action in TALOS; no automatic posting occurs on approval.

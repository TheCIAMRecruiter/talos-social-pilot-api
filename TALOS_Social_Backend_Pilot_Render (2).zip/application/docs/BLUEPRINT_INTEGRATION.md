# TALOS Social — Make blueprint integration (based on supplied exports)

## Verified source behavior
Authority Engine v8.0 is a scheduled Make router with five weekday branches (Monday–Friday). Each branch reads up to 30 published entries from `linkedin_post_history`, aggregates excerpts, prompts Claude, creates a pending approval record, and emails approval links. The approval handler receives `post_id` and `action` through a Make custom webhook. `approve` creates a public LinkedIn post and stores the returned LinkedIn post ID/URN; `reject` marks the original rejected, asks Claude for a materially different draft, stores a replacement pending draft, and emails a fresh approval request.

## White-label conversion — required changes
1. Replace hard-coded author biography, company claims, careers URL, recipient email, time zone, hashtags, and employer branding with tenant profile data.
2. Do not share a single Make Data Store, LinkedIn connection, approval webhook, or email connection across customers. Create isolated scenarios and credentials per tenant, or replace Make Data Store with a tenant-scoped backend API.
3. Make approvals authenticated POST actions from TALOS Social, never public GET links. The source blueprint contains approval URLs with actionable webhook tokens; rotate them before using any derivative deployment.
4. Keep `PENDING_APPROVAL`, `REJECTED`, `PUBLISHED` and `GENERATION_FAILED` behavior. Store `post_id`, `day_route`, `assignment_number`, `topic`, `hook_style`, `framework`, `authority_signal`, `post_text`, `similarity_score`, `linkedin_post_urn`, and timestamps.
5. Publishing must be opt-in and only use the tenant's authorized LinkedIn connection. Verify LinkedIn permissions and Make subscription limits before production.
6. Keep idempotency: each approval request must carry a unique action ID; duplicate requests must not create duplicate LinkedIn posts. Track publish failures separately and reconcile Make executions.
7. Do not claim `similarity_score` is calculated: the exported draft writers set it to zero. The prompt compares up to 30 posts semantically, but no independent scoring step is evident.

## Proposed integration contract
`POST /internal/make/draft` with tenant-authenticated signed payload: `{tenant_id, post_id, day_route, topic, post_text, framework, hook_style, authority_signal, assignment_number}`.
`POST /internal/make/published` with `{tenant_id, post_id, linkedin_post_urn, published_at, event_id}`.
`POST /internal/make/failed` with `{tenant_id, post_id, error_code, event_id}`.
The existing pilot server DOES NOT implement these endpoints. Build and test them before connecting live Make scenarios. Keep signatures and credentials server-side.

## Migration plan
A. Create one tenant and configure brand voice, careers URL, timezone, weekly schedule and allowed claim sources.
B. Clone the Make workflows into a test organization; replace all fixed references and rotate webhook URLs.
C. Route generated drafts into TALOS via authenticated callback, not a shared datastore.
D. Approve in TALOS; queue a signed publish job; ensure only a single job can publish a given post.
E. Send LinkedIn success/failure back to TALOS; reconcile on timeout.
F. Test rejection loop, two-tenant isolation, duplicate clicks, retries, disconnected accounts, and non-approved posts.

## Operational caveats
This document is a blueprint-specific integration guide, not evidence that live integrations are enabled. The supplied exports contain production-like references and should not be bundled or sent to customers unredacted.

# TALOS Social — Recruiter guide

1. Ask your administrator for an account in your organization's workspace.
2. Open the Content Studio, choose a posting category and add a specific topic or draft.
3. Use your own approved company facts. Never invent job openings, metrics, or testimonials.
4. Submit the draft for approval. A different authorized reviewer must approve it.
5. If rejected, review feedback and revise. Automatic AI regeneration is available only after the Make integration is connected.
6. Approved drafts can be queued; queued is NOT published. Verify the published state and LinkedIn link before reporting success.
7. Contact your administrator if branding, schedule, or profile appears to belong to another company.

# Reviewer guide
Check factual claims, candidate privacy, employer brand, current opening links, duplicates, and whether the author is authorized to speak for the company. Approve only verified posts. Reject with actionable feedback.

# Administrator guide
Configure branding and users; restrict publishing credentials to the correct organization; rotate webhook secrets; confirm an authorized LinkedIn connection; configure a schedule and audit trail; test with unpublished drafts first. Do not distribute the original Make exports to customers.

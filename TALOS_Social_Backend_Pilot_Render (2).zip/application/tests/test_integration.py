import os, tempfile, importlib.util
from pathlib import Path
from fastapi.testclient import TestClient

def test_mock_pipeline():
    with tempfile.TemporaryDirectory() as td:
        os.environ['TALOS_DB']=str(Path(td)/'test.db')
        os.environ['TALOS_BOOTSTRAP_EMAIL']='admin@example.com'
        os.environ['TALOS_BOOTSTRAP_PASSWORD']='long-random-test-password'
        spec=importlib.util.spec_from_file_location('talos_test_server',Path(__file__).resolve().parents[1]/'server.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        client=TestClient(module.app)
        def request(method,path,token=None,**kwargs):
            headers={'Authorization':'Bearer '+token} if token else {}
            return client.request(method,path,headers=headers,**kwargs)
        admin=request('POST','/api/login',json={'email':'admin@example.com','password':'long-random-test-password'}).json()['token']
        assert request('POST','/api/users',admin,json={'email':'author@example.com','password':'author-test-password','role':'recruiter'}).status_code==200
        assert request('POST','/api/users',admin,json={'email':'reviewer@example.com','password':'reviewer-test-password','role':'reviewer'}).status_code==200
        author=request('POST','/api/login',json={'email':'author@example.com','password':'author-test-password'}).json()['token']
        reviewer=request('POST','/api/login',json={'email':'reviewer@example.com','password':'reviewer-test-password'}).json()['token']
        pid=request('POST','/api/posts',author,json={'topic':'Recruiting','post_text':'Useful advice'}).json()['id']
        assert request('POST',f'/api/posts/{pid}/submit',author).status_code==200
        assert request('POST',f'/api/posts/{pid}/approve',author).status_code==403
        assert request('POST',f'/api/posts/{pid}/approve',reviewer).status_code==200
        assert request('POST',f'/api/posts/{pid}/publish',admin).status_code==200
        assert request('POST',f'/api/posts/{pid}/dispatch',admin).status_code==409
        assert request('PUT','/api/integration',admin,json={'mode':'mock'}).status_code==200
        result=request('POST',f'/api/posts/{pid}/dispatch',admin)
        assert result.status_code==200 and result.json()['simulated'] is True
        assert request('POST',f'/api/posts/{pid}/dispatch',admin).status_code==409
        assert request('GET','/api/posts',admin).json()[0]['status']=='published'
        assert request('GET','/api/dispatches',author).status_code==403
        print('PASS: authorization, separate reviewer, disabled integration, mock publication, idempotency, role isolation')

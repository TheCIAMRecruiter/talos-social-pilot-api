# TALOS Social — White-label recruiting content workspace

## Included

- `index.html`: original offline concept demo (browser localStorage only).
- `app.html` + `server.py`: authenticated, persistent self-hosted pilot with organization-scoped posts, user roles, approval separation, white-label settings, audit log, and publishing queue.
- `docs/DEPLOYMENT.md`: setup, security requirements, operations.
- `docs/MAKE_INTEGRATION.md`: original Make field mapping and safe connector architecture.
- `docs/WHITE_LABEL.md`: recruiter, reviewer, admin and reseller guides.

## Quick start

```
cd talos-social
python -m pip install -r requirements.txt
export TALOS_BOOTSTRAP_EMAIL=admin@example.com
export TALOS_BOOTSTRAP_PASSWORD='choose-a-unique-long-random-password'
uvicorn server:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. For Windows PowerShell use `$env:TALOS_BOOTSTRAP_EMAIL='...'` and analogous settings. Bootstrap credentials are used only if the account does not exist yet.

## Status and limits

**Phases 2–4 are implemented as a foundation, not finished production integrations.** The pilot supports real accounts, tenant-scoped data, human review, branding, and queue state. Make, LinkedIn publishing, AI generation, custom domains, customer self-service provisioning, billing, and hosting require further credentials, configuration, and engineering. Queuing does not publish. No live integrations are claimed.

The name TALOS Social has not been cleared for trademark or domain use.

## Integration update from supplied Make blueprints
See `docs/BLUEPRINT_INTEGRATION.md` for the actual five-route authority engine and approve/reject-regenerate workflow, `docs/WORKFLOW_MAP.json` for a sanitized module map, and `docs/RECRUITER_GUIDE.md` for customer-facing instructions. No live Make/LinkedIn connection is configured. Original blueprints are deliberately excluded to avoid disclosing actionable webhook URLs and personal connection details.

## New publishing integration (v1.1)
The Integration tab allows disabled, mock, or explicitly configured Make modes. Read `docs/LIVE_INTEGRATION_RUNBOOK.md` before enabling Make. The uploaded personal Make scenarios are NOT modified and the existing webhook is NOT used. Use `python -m pytest tests/test_integration.py -q` to run the simulated pipeline test. This is not yet a production-ready SaaS deployment.

## HTML refresh (October 2026)
`app.html` now includes all five weekday content missions, the publishing dispatch history, live connector setup instructions, and clarified regeneration limitations. This HTML requires the bundled FastAPI backend; opening the HTML file alone cannot authenticate or publish.

## Setup-first onboarding
On first launch, create the initial protected owner login. After signing in, the application presents a mandatory workspace configuration flow before the dashboard. Choose solo or team, customize branding and posting cadence, and optionally create an additional administrator and recruiter. The initial owner remains an administrator to avoid lockout. The onboarding completion flag is stored per organization. Publishing remains disabled by default. The standalone HTML requires the included backend for secure logins and saved configuration.
